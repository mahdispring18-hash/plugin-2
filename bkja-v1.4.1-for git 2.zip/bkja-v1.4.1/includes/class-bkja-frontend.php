<?php if ( ! defined( 'ABSPATH' ) ) exit;

class BKJA_Frontend {
    public static function init(){
        add_shortcode('bkja_assistant', array(__CLASS__,'render_chatbox'));
        add_action('wp_enqueue_scripts', array(__CLASS__,'enqueue_assets'));
        add_action('wp_ajax_bkja_send_message', array(__CLASS__,'ajax_send_message'));
        add_action('wp_ajax_nopriv_bkja_send_message', array(__CLASS__,'ajax_send_message'));
        add_action('wp_ajax_bkja_get_history', array(__CLASS__,'ajax_get_history'));
        add_action('wp_ajax_nopriv_bkja_get_history', array(__CLASS__,'ajax_get_history'));
    }

    public static function enqueue_assets(){
        wp_enqueue_style('bkja-frontend', BKJA_PLUGIN_URL.'assets/css/bkja-frontend.css', array(), '1.3.0');
        wp_enqueue_script('bkja-frontend', BKJA_PLUGIN_URL.'assets/js/bkja-frontend.js', array('jquery'), '1.3.0', true);
        $data = array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('bkja_nonce'),
            'is_logged_in' => is_user_logged_in() ? 1 : 0,
            'free_limit' => (int)get_option('bkja_free_messages_per_day',5)
        );
        wp_localize_script('bkja-frontend','bkja_vars',$data);
    }

    public static function render_chatbox($atts=array()){
        $atts = shortcode_atts(
            array('title'=>__('دستیار شغلی','bkja-assistant')),
            $atts,
            'bkja_assistant'
        );
        ob_start();
        include BKJA_PLUGIN_DIR.'templates/chatbox.php';
        return ob_get_clean();
    }

    public static function ajax_send_message(){
        check_ajax_referer('bkja_nonce','nonce');
        $message  = isset($_POST['message']) ? sanitize_textarea_field(wp_unslash($_POST['message'])) : '';
        $category = isset($_POST['category']) ? sanitize_text_field(wp_unslash($_POST['category'])) : '';
        $session  = isset($_POST['session']) ? sanitize_text_field(wp_unslash($_POST['session'])) : '';

        if ( empty($message) ) {
            wp_send_json_error(array('error'=>'empty_message'),400);
        }

        $user_id = get_current_user_id() ?: 0;
    $free_limit = (int)get_option('bkja_free_messages_per_day',5);
    // تعیین آدرس ورود/عضویت ووکامرس اگر فعال است
    $login_url = function_exists('wc_get_page_permalink') ? wc_get_page_permalink('myaccount') : wp_login_url();

        // اگر کاربر مهمان است، تعداد پیام‌های ارسالی را بررسی کن
        if(!$user_id){
            // session_id باید مقدار داشته باشد و معتبر باشد
            if(empty($session) || strpos($session, 'guest_') !== 0){
                wp_send_json_error(array('error'=>'invalid_session','msg'=>'جلسه مهمان معتبر نیست.'),400);
            }
            global $wpdb;
            $table = $wpdb->prefix . 'bkja_chats';
            // فقط پیام‌های واقعی کاربر مهمان را بشمار (response باید NULL باشد)
            $msg_count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE session_id = %s AND message IS NOT NULL AND response IS NULL", $session));
            if($msg_count >= $free_limit){
                wp_send_json_error(array('error'=>'guest_limit','msg'=>'برای ادامه گفتگو باید عضو سایت شوید.','login_url'=>$login_url),403);
            }
        }

        // save user message
        BKJA_Database::insert_chat(array(
            'user_id'      => $user_id ?: null,
            'session_id'   => $session,
            'job_category' => $category,
            'message'      => $message,
            'response'     => null
        ));

        $ai_response = BKJA_Chat::call_openai($message, array(
            'session_id' => $session,
            'user_id'    => $user_id,
            'category'   => $category,
        ));

        $suggestions = array();
        $reply_meta  = null;
        $from_cache  = false;
        if (is_wp_error($ai_response)) {
            $reply = 'خطا یا کلید API تنظیم نشده. '.$ai_response->get_error_message();
        } else {
            $reply = isset($ai_response['text']) ? (string)$ai_response['text'] : '';
            $suggestions = !empty($ai_response['suggestions']) && is_array($ai_response['suggestions']) ? $ai_response['suggestions'] : array();
            $from_cache = !empty($ai_response['from_cache']);
            $reply_meta = wp_json_encode(array(
                'suggestions'  => $suggestions,
                'context_used' => !empty($ai_response['context_used']),
                'from_cache'   => $from_cache,
                'source'       => isset($ai_response['source']) ? $ai_response['source'] : 'openai',
            ));
        }

        // save bot reply
        BKJA_Database::insert_chat(array(
            'user_id'      => $user_id ?: null,
            'session_id'   => $session,
            'job_category' => $category,
            'message'      => null,
            'response'     => $reply,
            'meta'         => $reply_meta
        ));

        wp_send_json_success(array(
            'reply'       => $reply,
            'suggestions' => $suggestions,
            'from_cache'  => $from_cache,
        ));
    }

    public static function ajax_get_history(){
        check_ajax_referer('bkja_nonce','nonce');

        $session = isset($_POST['session']) ? sanitize_text_field(wp_unslash($_POST['session'])) : '';
        $user_id = get_current_user_id() ?: 0;

        if ($user_id) {
            $rows = BKJA_Database::get_user_history($user_id,200);
        } else {
            if (empty($session)) {
                wp_send_json_error(array('error'=>'no_session'),400);
            }
            $rows = BKJA_Database::get_history_by_session($session,200);
        }

        $items = array();
        if ($rows) {
            foreach ($rows as $r) {
                $items[] = array(
                    'message'    => $r->message,
                    'response'   => $r->response,
                    'created_at' => $r->created_at
                );
            }
        }

        wp_send_json_success(array('items'=>$items));
    }
}