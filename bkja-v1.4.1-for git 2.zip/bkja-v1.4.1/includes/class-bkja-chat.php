<?php 
if ( ! defined( 'ABSPATH' ) ) exit;

class BKJA_Chat {

    // گرفتن API Key
    public static function get_api_key(){ 
        return trim(get_option('bkja_openai_api_key','')); 
    }

    // دریافت خلاصه و رکوردهای شغل مرتبط با پیام
    public static function get_job_context($message) {
        global $wpdb;
        $table = $wpdb->prefix . 'bkja_jobs';
        $like = '%' . $wpdb->esc_like($message) . '%';
        // پیدا کردن عنوان شغل مرتبط
        $row = $wpdb->get_row($wpdb->prepare("SELECT job_title FROM {$table} WHERE job_title LIKE %s LIMIT 1", $like));
        if(!$row) return [];
        $job_title = $row->job_title;
        // خلاصه و رکوردها
        $summary = class_exists('BKJA_Database') ? BKJA_Database::get_job_summary($job_title) : null;
        $records = class_exists('BKJA_Database') ? BKJA_Database::get_job_records($job_title, 5, 0) : [];
        return [
            'job_title' => $job_title,
            'summary'   => $summary,
            'records'   => $records
        ];
    }

    protected static function build_context_prompt( $context ) {
        if ( empty( $context['job_title'] ) ) {
            return '';
        }

        $title = $context['job_title'];
        $lines = array();
        $lines[] = "اطلاعات ساخت‌یافته داخلی درباره شغل «{$title}» برای استفاده در پاسخ:";
        if ( ! empty( $context['summary'] ) && is_array( $context['summary'] ) ) {
            $summary       = $context['summary'];
            $summary_parts = array();
            if ( ! empty( $summary['income'] ) ) {
                $summary_parts[] = 'میانگین درآمد: ' . $summary['income'];
            }
            if ( ! empty( $summary['investment'] ) ) {
                $summary_parts[] = 'میانگین سرمایه موردنیاز: ' . $summary['investment'];
            }
            if ( ! empty( $summary['cities'] ) ) {
                $summary_parts[] = 'شهرهای پرتکرار: ' . $summary['cities'];
            }
            if ( ! empty( $summary['advantages'] ) ) {
                $summary_parts[] = 'مزایا: ' . $summary['advantages'];
            }
            if ( ! empty( $summary_parts ) ) {
                $lines[] = 'جمع‌بندی تجربه کاربران: ' . implode( ' | ', $summary_parts );
            }
        }

        if ( ! empty( $context['records'] ) && is_array( $context['records'] ) ) {
            $records = array_slice( $context['records'], 0, 3 );
            $index   = 1;
            foreach ( $records as $record ) {
                if ( ! is_array( $record ) ) {
                    continue;
                }
                $parts = array();
                if ( ! empty( $record['income'] ) ) {
                    $parts[] = 'درآمد گزارش‌شده: ' . $record['income'];
                }
                if ( ! empty( $record['investment'] ) ) {
                    $parts[] = 'سرمایه اولیه: ' . $record['investment'];
                }
                if ( ! empty( $record['city'] ) ) {
                    $parts[] = 'شهر: ' . $record['city'];
                }
                if ( ! empty( $record['advantages'] ) ) {
                    $parts[] = 'مزایا: ' . $record['advantages'];
                }
                if ( ! empty( $record['disadvantages'] ) ) {
                    $parts[] = 'معایب: ' . $record['disadvantages'];
                }
                if ( ! empty( $parts ) ) {
                    $lines[] = 'تجربه ' . $index . ': ' . implode( ' | ', $parts );
                    $index++;
                }
                if ( ! empty( $record['details'] ) ) {
                    $lines[] = 'خلاصه تجربه: ' . $record['details'];
                }
            }
        }

        $lines[] = 'با استفاده از این داده‌ها پاسخ دقیق، مرحله‌به‌مرحله و فارسی ارائه بده.';
        return implode( "\n", array_filter( array_map( 'trim', $lines ) ) );
    }

    protected static function format_job_context_reply( $context ) {
        if ( empty( $context['job_title'] ) ) {
            return '';
        }

        $title = $context['job_title'];
        $lines = array();
        $lines[] = "🔎 اطلاعات جمع‌بندی شده درباره «{$title}»:";
        if ( ! empty( $context['summary'] ) && is_array( $context['summary'] ) ) {
            $summary = $context['summary'];
            if ( ! empty( $summary['income'] ) ) {
                $lines[] = '• 💵 میانگین درآمد: ' . $summary['income'];
            }
            if ( ! empty( $summary['investment'] ) ) {
                $lines[] = '• 💰 میانگین سرمایه اولیه: ' . $summary['investment'];
            }
            if ( ! empty( $summary['cities'] ) ) {
                $lines[] = '• 📍 شهرهای پرتکرار: ' . $summary['cities'];
            }
            if ( ! empty( $summary['genders'] ) ) {
                $lines[] = '• 👥 مناسب برای: ' . $summary['genders'];
            }
            if ( ! empty( $summary['advantages'] ) ) {
                $lines[] = '• ⭐ مزایای پرتکرار: ' . $summary['advantages'];
            }
            if ( ! empty( $summary['disadvantages'] ) ) {
                $lines[] = '• ⚠️ چالش‌های پرتکرار: ' . $summary['disadvantages'];
            }
        } else {
            $lines[] = '• هنوز داده‌ای درباره این شغل ثبت نشده است.';
        }

        if ( ! empty( $context['records'] ) && is_array( $context['records'] ) ) {
            $lines[] = '🧑‍💼 چند تجربه واقعی کاربران:';
            foreach ( array_slice( $context['records'], 0, 2 ) as $record ) {
                if ( ! is_array( $record ) ) {
                    continue;
                }
                $parts = array();
                if ( ! empty( $record['income'] ) ) {
                    $parts[] = 'درآمد: ' . $record['income'];
                }
                if ( ! empty( $record['investment'] ) ) {
                    $parts[] = 'سرمایه: ' . $record['investment'];
                }
                if ( ! empty( $record['city'] ) ) {
                    $parts[] = 'شهر: ' . $record['city'];
                }
                if ( ! empty( $record['details'] ) ) {
                    $parts[] = 'توضیح: ' . $record['details'];
                }
                if ( ! empty( $parts ) ) {
                    $lines[] = '  - ' . implode( ' | ', $parts );
                }
            }
        }

        $lines[] = 'اگر بخش خاصی از این شغل برات مهمه بگو تا دقیق‌تر راهنمایی‌ات کنم.';
        return implode( "\n", array_filter( array_map( 'trim', $lines ) ) );
    }

    protected static function build_followup_suggestions( $message, $context = array(), $answer = '' ) {
        $suggestions = array();
        $push = function( $text ) use ( &$suggestions ) {
            $text = trim( (string) $text );
            if ( $text && ! in_array( $text, $suggestions, true ) ) {
                $suggestions[] = $text;
            }
        };

        if ( ! empty( $context['job_title'] ) ) {
            $title = $context['job_title'];
            $push( "مهارت‌های ضروری برای موفقیت در «{$title}» چیست؟" );
            $push( "یک نقشه راه چند مرحله‌ای برای ورود به «{$title}» پیشنهاد بده." );
            $push( "شغل‌های مشابه «{$title}» با درآمد مناسب رو معرفی کن." );
        }

        if ( function_exists( 'mb_strtolower' ) ) {
            $haystack = mb_strtolower( $message, 'UTF-8' );
        } else {
            $haystack = strtolower( $message );
        }

        $keywordSuggestions = array(
            'سرمایه' => 'چه راهکارهایی برای کاهش سرمایه اولیه وجود دارد؟',
            'درآمد'  => 'چطور می‌توانم درآمد این حوزه را بیشتر کنم؟',
            'مهارت' => 'چه دوره یا منبعی برای یادگیری مهارت‌های لازم پیشنهاد می‌کنی؟',
            'شهر'    => 'در کدام شهرها یا محیط‌های کاری می‌توان این شغل را راحت‌تر پیدا کرد؟',
        );

        foreach ( $keywordSuggestions as $keyword => $textSuggestion ) {
            $found = function_exists( 'mb_strpos' ) ? mb_strpos( $haystack, $keyword ) : strpos( $haystack, $keyword );
            if ( $found !== false ) {
                $push( $textSuggestion );
            }
        }

        $fallbacks = array(
            'اگر بخوام مهارت‌هام رو برای این حوزه تقویت کنم از کجا شروع کنم؟',
            'برای اینکه بدونم این شغل به شخصیت من می‌خوره چه سوالاتی ازم می‌پرسی؟',
            'شغل یا کسب‌وکار دیگری که ارزش بررسی داشته باشه رو معرفی کن.',
        );
        foreach ( $fallbacks as $fallback ) {
            $push( $fallback );
        }

        return array_slice( $suggestions, 0, 3 );
    }

    protected static function build_response_payload( $text, $context, $message, $from_cache = false, $source = 'openai' ) {
        return array(
            'text'         => (string) $text,
            'suggestions'  => self::build_followup_suggestions( $message, $context, $text ),
            'context_used' => ! empty( $context['job_title'] ),
            'from_cache'   => (bool) $from_cache,
            'source'       => $source,
        );
    }

    public static function call_openai( $message, $args = array() ) {
        if ( empty( $message ) ) {
            return new WP_Error( 'empty_message', 'Message is empty' );
        }

        $defaults = array(
            'system'     => 'شما یک دستیار شغلی فارسی‌زبان و صمیمی هستید. پاسخ‌ها باید خلاصه‌ای یک‌خطی در ابتدا داشته باشند و سپس در قالب فهرست‌های مرتب و قابل اجرا ادامه پیدا کنند. از ایموجی‌های مرتبط برای خوانایی بهتر استفاده کنید، منابع یا داده‌های داخلی را صریح اعلام کنید و در پایان همیشه پیشنهاد ادامه گفتگو بدهید.',
            'model'      => 'gpt-3.5-turbo',
            'session_id' => '',
            'user_id'    => 0,
            'category'   => '',
        );
        $args    = wp_parse_args( $args, $defaults );
        $system  = ! empty( $args['system'] ) ? $args['system'] : $defaults['system'];
        $model   = $args['model'];

        $context = self::get_job_context( $message );

        $cache_components = array( $message );
        if ( ! empty( $args['category'] ) ) {
            $cache_components[] = $args['category'];
        }
        if ( ! empty( $context['job_title'] ) ) {
            $cache_components[] = $context['job_title'];
        }
        if ( ! empty( $args['user_id'] ) ) {
            $cache_components[] = 'u:' . (int) $args['user_id'];
        } elseif ( ! empty( $args['session_id'] ) ) {
            $cache_components[] = 's:' . $args['session_id'];
        }

        $cache_key = 'bkja_answer_' . md5( wp_json_encode( $cache_components ) );
        $cached    = get_transient( $cache_key );
        if ( false !== $cached ) {
            if ( is_array( $cached ) ) {
                $cached['from_cache'] = true;
                return $cached;
            }

            return self::build_response_payload( $cached, $context, $message, true, 'cache' );
        }

        $api_key = self::get_api_key();
        if ( empty( $api_key ) ) {
            if ( ! empty( $context ) ) {
                $fallback = self::build_response_payload( self::format_job_context_reply( $context ), $context, $message, false, 'job_context' );
                set_transient( $cache_key, $fallback, HOUR_IN_SECONDS );
                return $fallback;
            }

            return new WP_Error( 'no_api_key', 'API key not configured' );
        }

        $messages = array(
            array(
                'role'    => 'system',
                'content' => $system,
            ),
        );

        if ( ! empty( $context ) ) {
            $context_prompt = self::build_context_prompt( $context );
            if ( $context_prompt ) {
                $messages[] = array(
                    'role'    => 'system',
                    'content' => $context_prompt,
                );
            }
        }

        if ( class_exists( 'BKJA_Database' ) ) {
            $history = BKJA_Database::get_recent_conversation( $args['session_id'], (int) $args['user_id'], 6 );
            if ( ! empty( $history ) ) {
                foreach ( $history as $item ) {
                    if ( empty( $item['content'] ) ) {
                        continue;
                    }
                    $messages[] = array(
                        'role'    => $item['role'] === 'assistant' ? 'assistant' : 'user',
                        'content' => $item['content'],
                    );
                }
            }
        }

        $messages[] = array(
            'role'    => 'user',
            'content' => $message,
        );

        $payload = array(
            'model'       => $model,
            'messages'    => $messages,
            'temperature' => 0.2,
            'max_tokens'  => 650,
        );

        $request_args = array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json',
            ),
            'body'    => wp_json_encode( $payload ),
            'timeout' => 60,
        );

        $response = wp_remote_post( 'https://api.openai.com/v1/chat/completions', $request_args );
        if ( is_wp_error( $response ) ) {
            if ( ! empty( $context ) ) {
                $fallback = self::build_response_payload( self::format_job_context_reply( $context ), $context, $message, false, 'job_context' );
                set_transient( $cache_key, $fallback, HOUR_IN_SECONDS );
                return $fallback;
            }

            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body, true );

        if ( $code < 200 || $code >= 300 || empty( $data['choices'][0]['message']['content'] ) ) {
            if ( ! empty( $context ) ) {
                $fallback = self::build_response_payload( self::format_job_context_reply( $context ), $context, $message, false, 'job_context' );
                set_transient( $cache_key, $fallback, HOUR_IN_SECONDS );
                return $fallback;
            }

            return new WP_Error( 'api_error', 'OpenAI error: ' . substr( $body, 0, 250 ) );
        }

        $answer  = trim( $data['choices'][0]['message']['content'] );
        if ( '' === $answer && ! empty( $context ) ) {
            $answer = self::format_job_context_reply( $context );
            $source = 'job_context';
        } elseif ( '' === $answer ) {
            return new WP_Error( 'empty_response', 'Empty response from model' );
        } else {
            $source = 'openai';
        }

        $payload = self::build_response_payload( $answer, $context, $message, false, $source );
        set_transient( $cache_key, $payload, HOUR_IN_SECONDS );

        return $payload;
    }

}